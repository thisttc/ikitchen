// Stable keys are stored in JSON. Vite supplies production-safe asset URLs.
const images = {
'fridge/back.jpg': new URL('../assets/products/fridge/back.jpg', import.meta.url).href,
'fridge/left.jpg': new URL('../assets/products/fridge/left.jpg', import.meta.url).href,
'fridge/top.jpg': new URL('../assets/products/fridge/top.jpg', import.meta.url).href,
'fridge/bottom.jpg': new URL('../assets/products/fridge/bottom.jpg', import.meta.url).href,

'cabinet/back.jpg': new URL('../assets/products/cabinet/back.jpg', import.meta.url).href,
'cabinet/left.jpg': new URL('../assets/products/cabinet/left.jpg', import.meta.url).href,
'cabinet/top.jpg': new URL('../assets/products/cabinet/top.jpg', import.meta.url).href,
'cabinet/bottom.jpg': new URL('../assets/products/cabinet/bottom.jpg', import.meta.url).href,}
export function productImageUrl(ref) {
  if (!ref || typeof ref !== 'string') return null
  if (Object.hasOwn(images, ref)) return images[ref]
  try { const u = new URL(ref); return ['http:', 'https:'].includes(u.protocol) ? u.href : null } catch { return null }
}
const bitmapCache = new Map()
export function loadProductBitmap(ref) {
  const url = productImageUrl(ref)
  if (!url) return Promise.resolve(null)
  if (!bitmapCache.has(url)) {
    const promise = new Promise((resolve, reject) => {
      const img = new window.Image()
      img.crossOrigin = 'anonymous'
      img.onload = () => resolve(img)
      img.onerror = () => reject(new Error('โหลดไฟล์ภาพสินค้าไม่สำเร็จ'))
      img.src = url
    }).catch(error => { bitmapCache.delete(url); throw error })
    bitmapCache.set(url, promise)
  }
  return bitmapCache.get(url)
}
